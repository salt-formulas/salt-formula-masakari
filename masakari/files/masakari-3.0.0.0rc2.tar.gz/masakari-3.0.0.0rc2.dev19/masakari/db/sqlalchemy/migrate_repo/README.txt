This is a database migration repository.

More information at
http://code.google.com/p/sqlalchemy-migrate/
