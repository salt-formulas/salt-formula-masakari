========
Usage
========

To use masakari in a project::

    import masakari
