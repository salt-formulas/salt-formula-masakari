============
Installation
============

At the command line::

    $ pip install masakari

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv masakari
    $ pip install masakari
