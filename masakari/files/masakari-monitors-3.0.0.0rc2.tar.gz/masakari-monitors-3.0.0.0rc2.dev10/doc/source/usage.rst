========
Usage
========

To use masakari-monitors in a project::

    import masakarimonitors
